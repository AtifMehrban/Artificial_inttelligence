/*Example 1 */
/*facts*/
likes(dan,sally).
likes(sal,dan).
likes(josh,brritany).
likes(dan,sal).
/* Rules*/
dating(X,Y):- likes(X,Y),likes(Y,X).
friendship(X,Y):- likes(X,Y);likes(Y,X).
loves(sally,dan):- likes(dan,sally).
hate(X,Y):- likes(X,Y),not(likes(Y,X)). 


/* EXAMPLE 2*/
/*Facts */
male(albert).
male(saim).
male(nauman).
male(asghar).
male(yousaf).

female(alice).
female(saadia).
female(saaly).
female(safia).
female(sia).

happy(albert).
happy(alice).
happy(bob).
happy(bill).
with_albert(alice).
/* Rules*/
runs(albert) :- happy(albert).

dances(alice) :- happy(alice),with_albert(alice).
is_male(X):- not(female(X)).
is_female(X):- not(male(X)).
does_alice_dance :-  dances(alice),write('When Alice is happy and with Albert she dances').

/*EXAMPLE 3 */
/* Facts*/
parent(albert,bob).
parent(albert,betsy).
parent(albert,bill).


parent(alice, bob).
parent(alice, betsy).
parent(alice, bill).
parent(bob,carl).
parent(bob,charlie).

/* RULES*/
/* Grandchild--albert,bob,betsy,bill-------bob,betsy,bill are parent of -- ,*/
get_grandchild :- parent(albert,X),parent(X,Y),write('Alberts Grandchilds are: '), write(Y).

get_grandparent :- parent(X,bob),parent(X,charlie),parent(X,ahmed),format('~w ~s grandparent ~n',[X , "is the "]).

brother(bob,bill).
sister(betsy,bob).
/* Uncle Case*/
uncle(X,Y) :- parent(X,carl),brother(X,Y).


grand_parent(X,Y) :- parent(Z,X),parent(Y,Z),write(Z).


/* EXTRA */
what_grade(5) :- write('Go to Grade 5').
what_grade(6) :- write('Go to Grade 6').
what_grade(Other) :- Grade is Other -5, format('Go to grade ~w', [Grade]).



